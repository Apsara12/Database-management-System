<?php
$conn = mysqli_connect('localhost','root','','bgo') or die('Error'.mysqli_error());
session_start();

if(!isset($_SESSION['aid']))
{
    header('location:login_page.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>feedback</title>

<!-- font awesome cdn link  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<!-- custom css file link  -->
<link rel="stylesheet" href="style.css">

</head>
<body>
<?php include 'navbar3.php'; ?>

<div class="container">

<section class="shopping-cart1">

   <h1 class="heading">feedback </h1>

   <table>

      <thead>
         <th>Date</th>
         <th>User_id</th>
         <th>Name</th>
         <th>Email</th>
         <th>feedback</th>
      </thead>

      <tbody>

      <?php 
         
         $select_cart = mysqli_query($conn, "SELECT * FROM `feedback_info` ORDER BY date DESC");
         if(mysqli_num_rows($select_cart) > 0){
            while($fetch_cart = mysqli_fetch_assoc($select_cart)){
         ?>
      
         <tr>
            <td><?php echo $fetch_cart['date']; ?></td>
            <td><?php echo $fetch_cart['user_id']; ?></td>
            <td><?php echo $fetch_cart['name']; ?></td>
            <td><?php echo $fetch_cart['email']; ?></td>
            <td><?php echo $fetch_cart['message']; ?></td>
            
            
            
         </tr>
         <?php
          
            };
         };
         ?>
         

      </tbody>

   </table>

   

</section>

</div>
    
</body>
</html>
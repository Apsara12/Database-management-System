<?php

   function discountg( $_total)
   {
      if($_total>50000)
      {
         return 0.03;
      }
      else if($_total>250000)
      {
         return 0.04;
      }
      else if($_total>50000)
      {
         return 0.05;
      }
      if($_total>500000)
      {
         return 0.08;
      }
      else return 0;
   }

?>
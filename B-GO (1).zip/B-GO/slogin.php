<?php

$conn = mysqli_connect('localhost','root','','bgo') or die('Error'.mysqli_error());

session_start();

if(isset($_POST['submit'])){

   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = md5($_POST['password']);
   $select = " SELECT * FROM supplier WHERE email = '$email' && password = '$pass' ";

   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){

      $row = mysqli_fetch_array($result);

      if($row['user_type'] == 'admin'){

         $_SESSION['admin_name'] = $row['name'];
         $_SESSION['aid'] = $row['user_id'];
         header('location:admin.php');
        //  $_SESSION['aid'] = $row['user_id'];

      }elseif($row['user_type'] == 'user'){
        
         $_SESSION['user_name'] = $row['name'];
         $_SESSION['sid'] = $row['user_id'];
         header('location:seller.php');

      }
     
   }else{
      $error[] = 'incorrect email or password!';
   }

};
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - B-GO | Online Store</title>
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="stylesheet" href="style1.css">
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.1.1/css/fontawesome.min.css"> -->
    <link href="https://fonts.googleapis.com/css2?family=Signika+Negative:wght@300&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<body>



<div class="container">

    <div class="navbar">
        <div class="logo">
            <img src="images\last.png" width="125px">

        </div>
        <nav>
            <ul>
                <li><a href="">Home</a></li>
                <li><a href="">Products</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Contact</a></li>
                <li><a href="">Account</a></li>

        </ul>
    </nav>
    <img src="images/cart.png" width="30px" height="30px">
    

    </div>
    

</div>

<div class="account-page">
    <div class="container">
        <div class="row">
            <div class="col-2">
                <img src="images/homepage.jpg" width="80%">
            </div>
            <div class="col-2">
              <form action="" method="post">
                    <h3>login now</h3>
                    <?php
                        if(isset($error)){
                            foreach($error as $error){
                                echo '<span class="error-msg">'.$error.'</span>';
                            };
                         };
                        ?>
                            <input type="email" name="email" required placeholder="enter your email">
                            <input type="password" name="password" required placeholder="enter your password">
                            <input type="submit" name="submit" value="login now" class="form-btn">
                            <p>don't have an account? <a href="register_page.php">register now</a></p>
                </form>
            </div>
        </div>
    </div>

</div>



</body>
</html>
<?php
$conn = mysqli_connect('localhost','root','','bgo') or die('Error'.mysqli_error());
session_start();

if(!isset($_SESSION['uid']))
{
    header('location:login_page.php');
}


if(isset($_POST['update_update_btn'])){
   $update_value = $_POST['update_quantity'];
   $update_id = $_POST['update_quantity_id'];
   $update_quantity_query = mysqli_query($conn, "UPDATE `cart` SET quantity = '$update_value' WHERE pid = '$update_id'");
   if($update_quantity_query){
      header('location:cart.php');
   };
};

if(isset($_GET['remove'])){
   $remove_id = $_GET['remove'];
   mysqli_query($conn, "DELETE FROM `cart` WHERE pid = '$remove_id'");
   header('location:cart.php');
};

if(isset($_GET['delete_all'])){
   mysqli_query($conn, "DELETE FROM `cart` Where id user_id = ".$_SESSION['uid']);
   header('location:cart.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>shopping cart</title>

<!-- font awesome cdn link  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<!-- custom css file link  -->
<link rel="stylesheet" href="style.css">

</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container">

<section class="shopping-cart">

   <h1 class="heading">shopping cart</h1>

   <table>

      <thead>
         <th>image</th>
         <th>name</th>
         <th>category</th>
         <th>Color</th>
         <th>price</th>
         <th>quantity</th>
         <th>total price</th>
         <th>action</th>
      </thead>

      <tbody>

         <?php 
         $sql = "SELECT pid, quantity FROM cart WHERE user_id = ".$_SESSION['uid'];
         $sub_result = mysqli_query($conn, $sql);
         $cart_products = array();
         $quantity = array();
         if(mysqli_num_rows($sub_result) > 0){
            while($fetch_cart = mysqli_fetch_assoc($sub_result)){
               array_push($cart_products, $fetch_cart['pid']);
               $quantity[$fetch_cart['pid']] = $fetch_cart['quantity'];
            }

            $cart_products = '('.implode(', ', $cart_products).')';
            $sql = "SELECT * FROM product_info WHERE pid IN ".$cart_products;
            
            $select_cart = mysqli_query($conn, $sql);
            $grand_total = 0;
            if(mysqli_num_rows($select_cart) > 0){
               while($fetch_cart = mysqli_fetch_assoc($select_cart)){
         ?>

         <tr>
            <td><img src="uploaded_img/<?php echo $fetch_cart['image']; ?>" height="100" alt=""></td>
            <td><?php echo $fetch_cart['product_name']; ?></td>
            <td><?php echo $fetch_cart['category']; ?></td>
            <td><?php echo $fetch_cart['colour']; ?></td>
            <td>Rs<?php echo number_format($fetch_cart['price']); ?>/-</td>
            <td>
               <form action="" method="post">
                  <input type="hidden" name="update_quantity_id"  value="<?php echo $fetch_cart['pid']; ?>" >
                  <input type="number" name="update_quantity" min="1" max="<?php echo $fetch_cart['stock']; ?>"  value="<?php echo $quantity[$fetch_cart['pid']]; ?>" >
                  <input type="submit" value="update" name="update_update_btn">
               </form>   
            </td>
            <td>Rs<?php echo $sub_total = $fetch_cart['price'] * $quantity[$fetch_cart['pid']]; ?>/-</td>
            <td><a href="cart.php?remove=<?php echo $fetch_cart['pid']; ?>" onclick="return confirm('remove item from cart?')" class="delete-btn"> <i class="fas fa-trash"></i> remove</a></td>
         </tr>
         <?php
           $grand_total += $sub_total;  
            };
         }
         };
         ?>
         <tr class="table-bottom">
            <td><a href="index.php" class="option-btn" style="margin-top: 0;">continue shopping</a></td>
            <td></td>
            <td></td>
            <td colspan="3">grand total</td>
            <td>Rs:<?php echo isset($grand_total)?number_format($grand_total):'0'; ?></td>
            
            <td><a href="cart.php?delete_all" onclick="return confirm('are you sure you want to delete all?');" class="delete-btn"> <i class="fas fa-trash"></i> delete all </a></td>
         </tr>

      </tbody>

   </table>

   <div class="checkout-btn">
      <a href="checkout.php" class="btn <?= ($grand_total > 1)?'':'disabled'; ?>">procced to checkout</a>
   </div>

</section>

</div>
    
</body>
</html>
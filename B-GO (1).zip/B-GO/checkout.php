
<?php
$conn = mysqli_connect('localhost','root','','bgo') or die('Error'.mysqli_error());
session_start();
include 'function.php';

if(!isset($_SESSION['uid']))
{
    header('location:login_page.php');
}


if(isset($_POST['order_btn'])){


   $adress2 = $_POST['adress2'];
   $message= $_POST['feedback'];

   $tsql= "SELECT * from total_transactions where user_id= ".$_SESSION['uid'];
   $dis_query = mysqli_query($conn, $tsql);
   if(mysqli_num_rows($dis_query) > 0)
      {
         while($dis_detail= mysqli_fetch_assoc($dis_query))
         {
            if($userid=$dis_detail['user_id']){
             $total =$dis_detail['total'];
   
            };
         };
      }
      else 
      {
         $total=0;
      }
   
   $reward=discountg($total);
   $sql = "SELECT * FROM `order_info` WHERE user_id = ".$_SESSION['uid'];
   $cart_query = mysqli_query($conn, $sql);
   $price_total = 0;
   if(mysqli_num_rows($cart_query) > 0){
      while($product_item = mysqli_fetch_assoc($cart_query)){
         $product_name[] = $product_item['product_name'] .' ('. $product_item['quantity'] .') ';
         $product_price = $product_item['price'] * $product_item['quantity'];
         $price_total += $product_price;

         $supplier_id=$product_item['a_id'];

         // $_reward=discountg($_total);
         $disamount= $reward*$price_total;
         $ftotal=$price_total-$disamount;

         $userid=$product_item['user_id'];
         $stock = $product_item['stock'];
         $quantity = $product_item['quantity'];

         $upid= $product_item['pid'];
         $new_stock=$stock-$quantity;
         $up=" UPDATE `product_details` SET stock='$new_stock' where pid='$upid'";
         $update_query= mysqli_query($conn,$up);
      };
   };
   // $conn = mysqli_connect('localhost','root','','bgo') or die('Error'.mysqli_error());
   // $sql= "SELECT * from total_transactions where user_id= ".$_SESSION['uid'];
   // $dis_query = mysqli_query($conn, $sql);
   // if(mysqli_num_rows($dis_query) > 0)
   //    {
   //       while($dis_detail= mysqli_fetch_assoc($dis_query))
   //       {
   //          if($userid=$dis_detail['user_id']){
   //           $_total =$dis_detail['total'];
   
   //          };
   //       };
   //    };

   $sql = "SELECT * FROM `user_form` WHERE user_id = ".$_SESSION['uid'];
   $user_query= mysqli_query($conn, $sql);

   if(mysqli_num_rows($user_query) > 0)
   {
      while($user_detail= mysqli_fetch_assoc($user_query))
      {
         if($userid=$user_detail['user_id']){
         $_name= $user_detail['name'];
         $_email= $user_detail['email'];
         $_contact= $user_detail['contact'];
         $_adress1= $user_detail['address'];

         };
      };
   };
   $t_total=$total+$ftotal;
   $uid=$_SESSION['uid'];
   $tsql="CALL update_table($uid,$t_total)";
   $dis_query = mysqli_query($conn, $tsql);
   // if(mysqli_num_rows($dis_query) > 0)
   //    {
   //       while($dis_detail= mysqli_fetch_assoc($dis_query))
   //       {
   //          if($_SESSION['uid']=$dis_detail['user_id']){
   //             $transaction_query= mysqli_query($conn, "UPDATE `total_transactions` SET total='$t_total' WHERE user_id=".$_SESSION['uid']) or die('query failed');
   
   //          }
   //          else
   //          {
   //             $transaction_query=mysqli_query($conn,"INSERT INTO `total_transactions`(user_id,total) VALUES ('$userid','$_ftotal')")or die('query failed');
   //          }
   //       };
   //    };


   $total_product = implode(', ',$product_name);
   $detail_query = mysqli_query($conn, "INSERT INTO `order_details`(name, number, email, adress1, adress2, total_products, total_price, user_id,a_id) VALUES('$_name','$_contact','$_email','$_adress1','$adress2','$total_product','$ftotal','$userid',$supplier_id)") or die('query failed');

   // $transaction_query=mysqli_query($conn,"INSERT INTO `total_transactions`(user_id,total) VALUES ('$userid','$_ftotal')")or die('query failed');
   $sql= "SELECT * FROM `order_details` ORDER BY orderid DESC Limit 1";
   $detail_query1=mysqli_query($conn, $sql);
   $order_detail=mysqli_fetch_assoc($detail_query1);
   $orderid=$order_detail['orderid'];

   $order_query= mysqli_query($conn,"INSERT INTO `delivery`(orderid) VALUES ('$orderid')");
   if($cart_query && $detail_query){
      echo "
      <div class='order-message-container'>
      <div class='message-container'>
         <h3>thank you for shopping!</h3>
         <div class='order-detail'>
            <span>".$total_product."</span>
            
            <li>Total: RS ".$price_total."/-</li><br>
            
            <li>Discount: RS ".$disamount."/-</li>
            <span class='total'> Net Total : Rs:".$ftotal."/-  </span>
         </div>
         <div class='customer-details'>
            <p>  Dear  <span>".$_name."</span> your order had been placed. </p>
            <p>(*pay when product arrives*)</p>
            <p> Happy Shopping ;) !!!!</p>
         </div>
            <a href='index.php' class='btn'>continue shopping</a>
         </div>
      </div>
      ";
   }
   $detail_query = mysqli_query($conn, "INSERT INTO `feedback`(user_id,message) VALUES('$userid','$message')") or die('query failed');
   
   // $transaction_query= mysqli_query($conn, "UPDATE `total_transactions` total='$t_total' WHERE user_id='$userid' ") or die('query failed');

   mysqli_query($conn, "DELETE FROM `cart` where user_id = ".$_SESSION['uid']);
    

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>checkout</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="style.css">

</head>
<body>
<?php include 'navbar.php'; ?>



<div class="container">

<section class="checkout-form">

   <h1 class="heading">complete your order</h1>

   <form action="" method="post">

   <div class="display-order">
      <?php
        
         $select_cart = mysqli_query($conn, "SELECT * FROM `order_info` WHERE user_id = ".$_SESSION['uid']);
         $total = 0;
         $grand_total = 0;
         if(mysqli_num_rows($select_cart) > 0){
            while($fetch_cart = mysqli_fetch_assoc($select_cart)){
            $total_price = $fetch_cart['price'] * $fetch_cart['quantity'];
            $grand_total = $total += $total_price;
      ?>
      <span><?= $fetch_cart['product_name']; ?>(<?= $fetch_cart['quantity']; ?>)</span>
      <?php
         }
      }else{
         echo "<div class='display-order'><span>your cart is empty!</span></div>";
      }
      ?>
      <span class="grand-total"> grand total : Rs <?= number_format($grand_total); ?> </span>
   </div>

      <div class="flex">
         <div class="inputBox">
            <span>Secondary Adress (if any)</span>
            <input type="text" placeholder="Enter the adress if you want to deliver in diffrent location " name="adress2" >
         </div>
         <div class="inputBox">
            <span>Feedback</span>
            <input type="text" placeholder="if-any" name="feedback" required>
         </div>
      </div>
      <input type="submit" value="order now" name="order_btn" class="btn">
   </form>

</section>

</div>
   
</body>
</html>
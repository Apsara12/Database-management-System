<?php
$conn = mysqli_connect('localhost','root','','bgo') or die('Error'.mysqli_error());
session_start();

if(!isset($_SESSION['aid']))
{
    header('location:login_page.php');
}

if(isset($_POST['update_update_btn'])){
    $update_status=$_POST['status'];
    $update_did= $_POST['d_id'];

//    $update_value = $_POST['update_quantity'];
//    $update_id = $_POST['update_quantity_id'];
   $sql= "UPDATE `delivery` SET status = '$update_status' WHERE d_id = '$update_did'";
   $update_quantity_query = mysqli_query($conn, $sql);
   if($update_quantity_query){
      header('location:delivery.php');
   };
};

if(isset($_GET['remove'])){
    $remove_id = $_GET['remove'];
    $sql="DELETE FROM `delivery` WHERE d_id = '$remove_id'";
    mysqli_query($conn,$sql);
    header('location:delivery.php');
 };
 



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order</title>

<!-- font awesome cdn link  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<!-- custom css file link  -->
<link rel="stylesheet" href="style.css">

</head>
<body>
<?php include 'navbar2.php'; ?>

<div class="container">

<section class="shopping-cart1">

   <h1 class="heading">Order </h1>

   <table>

      <thead>
         <th>Order date</th>
         <th>Name</th>
         <th>Product</th>
         <th>Total cost</th>
         <th>Adress</th>
         <th>Email</th>
         <th>Phone number</th>
         <th>Staus</th>
         <th>action</th>
      </thead>

      <tbody>

      <?php 
         
         $select_cart = mysqli_query($conn, "SELECT * FROM `delivery_info` ORDER BY added_on DESC");
         if(mysqli_num_rows($select_cart) > 0){
            while($fetch_cart = mysqli_fetch_assoc($select_cart)){
         ?>
      
         <tr>
            <td><?php echo $fetch_cart['added_on']; ?></td>
            <td><?php echo $fetch_cart['name']; ?></td>
            <td><?php echo $fetch_cart['total_products']; ?></td>
            <td>Rs<?php echo number_format($fetch_cart['total_price']); ?></td>
            <td><?php echo $fetch_cart['adress1']; ?><br>-------------<br><?php echo $fetch_cart['adress2']; ?></td>
            <td><?php echo $fetch_cart['email']; ?></td>
            <td><?php echo $fetch_cart['number']; ?></td>
            
            <td><?php echo $fetch_cart['status']; ?></td>
            <td>
            <form action="" method="post">
                <select name="status">
                  
                  <option value="" disabled hidden selected>Status</option> -->
                  <option value="Order Placed">Order Placed</option>
                  <option value="shipping">Shipping</option>
                  <option value="Delivered">Delivered</option>
   
                </select>
                <input type="hidden" name="d_id" value="<?php echo $fetch_cart['d_id']; ?>">
               <input type="submit" value="update" name="update_update_btn">  
            </form action="" method="get">

                <a href="delivery.php?remove=<?php echo $fetch_cart['d_id']; ?>" onclick="return confirm('Are you sure to remove this?')" class="delete-btn"> <i class="fas fa-trash"></i> remove</a></td>
         </tr>
         <?php
          
            };
         };
         ?>
         

      </tbody>

   </table>

   

</section>

</div>
    
</body>
</html>
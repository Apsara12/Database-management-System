-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2022 at 03:39 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bgo`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_table` (IN `uid` INT, IN `amt` FLOAT)   BEGIN 
	DECLARE temp INT DEFAULT 0;
    SELECT user_id INTO temp FROM total_transactions WHERE user_id = uid;
    IF uid = temp THEN
		UPDATE total_transactions SET total = total + amt WHERE user_id = uid;
	ELSE
		INSERT INTO total_transactions VALUES (uid,amt);
	END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `pid` int(255) DEFAULT NULL,
  `a_id` int(100) NOT NULL,
  `user_id` int(255) DEFAULT NULL,
  `quantity` int(100) NOT NULL,
  `cart_price` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `d_id` int(11) NOT NULL,
  `orderid` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT 'order placed',
  `added_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`d_id`, `orderid`, `status`, `added_on`) VALUES
(1, 3, 'order placed', '2022-07-29 09:31:28'),
(2, 4, 'order placed', '2022-07-29 09:31:28'),
(3, 5, 'order placed', '2022-07-29 09:31:28'),
(4, 6, 'order placed', '2022-07-29 09:31:28'),
(5, 7, 'shipping', '2022-07-29 09:39:09');

-- --------------------------------------------------------

--
-- Stand-in structure for view `delivery_info`
-- (See below for the actual view)
--
CREATE TABLE `delivery_info` (
`orderid` int(11)
,`name` varchar(255)
,`number` int(10)
,`email` varchar(50)
,`adress1` varchar(255)
,`adress2` varchar(255)
,`user_id` int(255)
,`total_price` int(100)
,`total_products` varchar(255)
,`a_id` varchar(255)
,`d_id` int(11)
,`status` varchar(255)
,`added_on` timestamp
);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `f_id` int(11) NOT NULL,
  `date` timestamp(6) NULL DEFAULT current_timestamp(6),
  `user_id` int(11) DEFAULT NULL,
  `message` varchar(255) DEFAULT '-'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`f_id`, `date`, `user_id`, `message`) VALUES
(2, '2022-07-26 07:01:01.768396', 4, 'so many bug'),
(3, '2022-07-26 07:05:00.862415', 3, 'please add more product and work on bugs otherwsie so happy to buy products from here'),
(4, '2022-07-26 07:34:50.637158', 4, 'no variety in products'),
(5, '2022-07-26 14:01:13.657349', 4, 'please add more product'),
(6, '2022-07-26 14:37:26.053789', 4, 'worst quality'),
(8, '2022-07-26 14:42:25.728102', 4, 'worst website'),
(12, '2022-07-27 11:52:36.102365', 4, 'please add more item'),
(13, '2022-07-27 11:54:04.761908', 4, 'slow process'),
(16, '2022-07-28 13:11:36.557830', 4, 'worst experience'),
(27, '2022-07-28 15:09:40.160330', 4, 'nai malie tha xaina'),
(28, '2022-07-28 15:10:49.192170', 4, 'ma marey ni mero desh bachi rahos'),
(30, '2022-07-28 15:31:22.390876', 4, 'Please deliver it on time'),
(31, '2022-07-28 15:44:30.149102', 4, 'sdhjaj'),
(32, '2022-07-28 15:46:54.437199', 4, 'abcd'),
(33, '2022-07-28 16:54:46.878096', 14, 'abcd'),
(34, '2022-07-28 16:56:59.438475', 14, 'dimakh hang vayooo mero'),
(35, '2022-07-29 06:31:22.946914', 4, 'nice design'),
(36, '2022-07-29 06:36:53.550112', 4, 'hello'),
(37, '2022-07-29 06:38:36.998638', 4, 'lkekoq'),
(38, '2022-07-29 06:47:25.499582', 4, 'sdsks'),
(39, '2022-07-29 07:27:14.422767', 4, 'aksa'),
(40, '2022-07-29 07:30:15.513853', 3, 'nice shoes'),
(41, '2022-07-29 07:41:12.957164', 4, 'hello dear'),
(42, '2022-07-29 09:19:03.470911', 4, 'nice design'),
(43, '2022-07-29 09:39:09.671088', 4, 'hello');

-- --------------------------------------------------------

--
-- Stand-in structure for view `feedback_info`
-- (See below for the actual view)
--
CREATE TABLE `feedback_info` (
`user_id` int(255)
,`name` varchar(255)
,`email` varchar(255)
,`contact` varchar(256)
,`address` varchar(255)
,`password` varchar(255)
,`user_tye` varchar(255)
,`f_id` int(11)
,`date` timestamp(6)
,`message` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `orderid` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `number` int(10) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `adress1` varchar(255) DEFAULT NULL,
  `adress2` varchar(255) DEFAULT '-',
  `user_id` int(255) DEFAULT NULL,
  `total_price` int(100) DEFAULT NULL,
  `total_products` varchar(255) DEFAULT NULL,
  `a_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`orderid`, `name`, `number`, `email`, `adress1`, `adress2`, `user_id`, `total_price`, `total_products`, `a_id`) VALUES
(1, 'apsara shrestha', 2147483647, 'apsu717@gmail.com', 'Imadol,lalitpur', '', 4, 2425, 'bagpack (1) ', '2'),
(2, 'apsara shrestha', 2147483647, 'apsu717@gmail.com', 'Imadol,lalitpur', '', 4, 2425, 'bagpack (1) ', '2'),
(3, 'apsara shrestha', 2147483647, 'apsu717@gmail.com', 'Imadol,lalitpur', '', 4, 2425, 'bagpack (1) ', '2'),
(4, 'nitika paudel', 2147483647, 'nitey@gmail.com', 'Sanjivani marga, koteswor,Kathmandu', '', 3, 4000, 'sport  shoes (2) ', '2'),
(5, 'apsara shrestha', 2147483647, 'apsu717@gmail.com', 'Imadol,lalitpur', '', 4, 4171, 'sport  shoes (1) , onepiece (1) ', '3'),
(6, 'apsara shrestha', 2147483647, 'apsu717@gmail.com', 'Imadol,lalitpur', 'thapathali', 4, 5000, 'bagpack (2) ', '2'),
(7, 'apsara shrestha', 2147483647, 'apsu717@gmail.com', 'Imadol,lalitpur', '', 4, 5000, 'bagpack (2) ', '2');

-- --------------------------------------------------------

--
-- Stand-in structure for view `order_info`
-- (See below for the actual view)
--
CREATE TABLE `order_info` (
`pid` int(255)
,`a_id` int(100)
,`cart_id` int(11)
,`user_id` int(255)
,`quantity` int(100)
,`cart_price` int(100)
,`Added on` datetime
,`product_name` varchar(255)
,`price` varchar(255)
,`image` varchar(255)
,`detail` varchar(255)
,`colour` varchar(100)
,`stock` int(100)
,`category` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Added on` datetime NOT NULL DEFAULT current_timestamp(),
  `pid` int(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `a_id` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Added on`, `pid`, `product_name`, `price`, `image`, `a_id`) VALUES
('2022-07-25 22:00:58', 2, 'T-shirt', '800', 'buy-1.jpg', 2),
('2022-07-25 22:00:58', 3, 'kurta', '1800', '1.jpg', 1),
('2022-07-25 22:00:58', 5, 'Mask', '150', 'ladies8.png', 1),
('2022-07-25 22:00:58', 6, 'Kurti', '2500', 'gents16.png', 3),
('2022-07-26 19:40:46', 7, 'Blazer', '2000', 'gents15.png', 2),
('2022-07-26 19:42:42', 8, 'sports shoes', '2000', 'product-10.jpg', 2),
('2022-07-26 19:43:32', 9, 'Hat', '500', 'ladies7.png', 3),
('2022-07-29 08:49:44', 11, 'bagpack', '2500', 'gents10.png', 2),
('2022-07-29 12:06:52', 12, 'sport  shoes', '2000', 'gents5.png', 2),
('2022-07-29 13:25:48', 13, 'onepiece', '2300', 'ladies12.png', 3);

-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `detail` varchar(255) NOT NULL,
  `colour` varchar(100) NOT NULL,
  `stock` int(100) NOT NULL,
  `category` varchar(20) NOT NULL,
  `pid` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_details`
--

INSERT INTO `product_details` (`detail`, `colour`, `stock`, `category`, `pid`) VALUES
('suitable for this summer', 'Red', 5, 'gents', 2),
('for this festive season', 'Orange', 19, 'Ladies', 3),
('Especially for bts lover', 'Black', 70, 'Ladies', 5),
('for this festive season', 'Green and white', 5, 'gents', 6),
('100% pure cotton', 'Marun', 3, 'gents', 7),
('Especially for hiking', 'black', 4, 'gents', 8),
('protect yourself from sun', 'yellow', 2, 'Ladies', 9),
('Laptop bag 100% water proof', 'Black', 5, 'gents', 11),
('1 yrs warranty', 'white and orange', 7, 'gents', 12),
('nice design', 'Black', 119, 'Ladies', 13);

-- --------------------------------------------------------

--
-- Stand-in structure for view `product_info`
-- (See below for the actual view)
--
CREATE TABLE `product_info` (
`pid` int(255)
,`detail` varchar(255)
,`colour` varchar(100)
,`stock` int(100)
,`category` varchar(20)
,`Added on` datetime
,`product_name` varchar(255)
,`price` varchar(255)
,`image` varchar(255)
,`a_id` int(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `a_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`a_id`, `name`, `email`, `contact`, `address`, `password`, `user_type`) VALUES
(1, 'manoj paudel', 'mnzpdel@gmail.com', '9876543210', 'awaroad 2 baglung', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin'),
(2, 'apsara shrestha', 'aps.shrestha@gmail.com', '9875432180', 'Imadol,lalitpur', '5f4dcc3b5aa765d61d8327deb882cf99', 'supplier'),
(3, 'Sabu Dahal', 'sabi.dahal@gmail.com', '9805198245', 'pipalbot,Boudha Kathmandu', 'db8ff0d351387313fecab4d520a7e6d2', 'supplier');

-- --------------------------------------------------------

--
-- Stand-in structure for view `supplier_info`
-- (See below for the actual view)
--
CREATE TABLE `supplier_info` (
`a_id` int(100)
,`pid` int(255)
,`Added on` datetime
,`product_name` varchar(255)
,`price` varchar(255)
,`image` varchar(255)
,`detail` varchar(255)
,`colour` varchar(100)
,`stock` int(100)
,`category` varchar(20)
,`name` varchar(255)
,`email` varchar(255)
,`contact` varchar(255)
,`address` varchar(255)
,`password` varchar(255)
,`user_type` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `total_transactions`
--

CREATE TABLE `total_transactions` (
  `user_id` int(100) NOT NULL,
  `total` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `total_transactions`
--

INSERT INTO `total_transactions` (`user_id`, `total`) VALUES
(3, '4000'),
(4, '15000'),
(14, '3100');

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

CREATE TABLE `user_form` (
  `user_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(256) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_tye` varchar(255) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_form`
--

INSERT INTO `user_form` (`user_id`, `name`, `email`, `contact`, `address`, `password`, `user_tye`) VALUES
(3, 'nitika paudel', 'nitey@gmail.com', '9876512340', 'Sanjivani marga, koteswor,Kathmandu', '7cc92f0fa54e63fc23c8554c07f3cce8', 'user'),
(4, 'apsara shrestha', 'apsu717@gmail.com', '9812376504', 'Imadol,lalitpur', '4f5ace8281c279496af3babd5aa7c640', 'user'),
(5, 'manoj paudel', 'mnzpdel@gmail.com', '9801267453', 'Sanjivani marga, koteswor,Kathmandu', 'b8a1c5a789abf37ce5ecd3d9419a7efc', 'user'),
(9, 'Apsara Shrestha', 'apsara123@gmail.com', '9876543102', 'Imadol,lalitpur', '9ece85ed2c15f50e1f6ad8fedd27f714', 'admin'),
(14, 'Sabina dahal', 'sabudahal@gmail.com', '9805198245', 'pipalbot,Boudha Kathmandu', '5f4dcc3b5aa765d61d8327deb882cf99', 'user'),
(15, 'sujana acharya', 'sujana.ach@gmail.com', '9876459120', 'godawari lalitpur', '5f4dcc3b5aa765d61d8327deb882cf99', 'user');

-- --------------------------------------------------------

--
-- Structure for view `delivery_info`
--
DROP TABLE IF EXISTS `delivery_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `delivery_info`  AS SELECT `order_details`.`orderid` AS `orderid`, `order_details`.`name` AS `name`, `order_details`.`number` AS `number`, `order_details`.`email` AS `email`, `order_details`.`adress1` AS `adress1`, `order_details`.`adress2` AS `adress2`, `order_details`.`user_id` AS `user_id`, `order_details`.`total_price` AS `total_price`, `order_details`.`total_products` AS `total_products`, `order_details`.`a_id` AS `a_id`, `delivery`.`d_id` AS `d_id`, `delivery`.`status` AS `status`, `delivery`.`added_on` AS `added_on` FROM (`order_details` join `delivery` on(`order_details`.`orderid` = `delivery`.`orderid`))  ;

-- --------------------------------------------------------

--
-- Structure for view `feedback_info`
--
DROP TABLE IF EXISTS `feedback_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `feedback_info`  AS SELECT `user_form`.`user_id` AS `user_id`, `user_form`.`name` AS `name`, `user_form`.`email` AS `email`, `user_form`.`contact` AS `contact`, `user_form`.`address` AS `address`, `user_form`.`password` AS `password`, `user_form`.`user_tye` AS `user_tye`, `feedback`.`f_id` AS `f_id`, `feedback`.`date` AS `date`, `feedback`.`message` AS `message` FROM (`user_form` join `feedback` on(`user_form`.`user_id` = `feedback`.`user_id`))  ;

-- --------------------------------------------------------

--
-- Structure for view `order_info`
--
DROP TABLE IF EXISTS `order_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `order_info`  AS SELECT `cart`.`pid` AS `pid`, `cart`.`a_id` AS `a_id`, `cart`.`cart_id` AS `cart_id`, `cart`.`user_id` AS `user_id`, `cart`.`quantity` AS `quantity`, `cart`.`cart_price` AS `cart_price`, `product`.`Added on` AS `Added on`, `product`.`product_name` AS `product_name`, `product`.`price` AS `price`, `product`.`image` AS `image`, `product_details`.`detail` AS `detail`, `product_details`.`colour` AS `colour`, `product_details`.`stock` AS `stock`, `product_details`.`category` AS `category` FROM (`cart` join (`product` join `product_details` on(`product`.`pid` = `product_details`.`pid`)) on(`cart`.`pid` = `product`.`pid` and `cart`.`a_id` = `product`.`a_id`))  ;

-- --------------------------------------------------------

--
-- Structure for view `product_info`
--
DROP TABLE IF EXISTS `product_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `product_info`  AS SELECT `product_details`.`pid` AS `pid`, `product_details`.`detail` AS `detail`, `product_details`.`colour` AS `colour`, `product_details`.`stock` AS `stock`, `product_details`.`category` AS `category`, `product`.`Added on` AS `Added on`, `product`.`product_name` AS `product_name`, `product`.`price` AS `price`, `product`.`image` AS `image`, `product`.`a_id` AS `a_id` FROM (`product_details` join `product` on(`product_details`.`pid` = `product`.`pid`))  ;

-- --------------------------------------------------------

--
-- Structure for view `supplier_info`
--
DROP TABLE IF EXISTS `supplier_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `supplier_info`  AS SELECT `product`.`a_id` AS `a_id`, `product`.`pid` AS `pid`, `product`.`Added on` AS `Added on`, `product`.`product_name` AS `product_name`, `product`.`price` AS `price`, `product`.`image` AS `image`, `product_details`.`detail` AS `detail`, `product_details`.`colour` AS `colour`, `product_details`.`stock` AS `stock`, `product_details`.`category` AS `category`, `supplier`.`name` AS `name`, `supplier`.`email` AS `email`, `supplier`.`contact` AS `contact`, `supplier`.`address` AS `address`, `supplier`.`password` AS `password`, `supplier`.`user_type` AS `user_type` FROM ((`product` join `product_details` on(`product`.`pid` = `product_details`.`pid`)) join `supplier` on(`product`.`a_id` = `supplier`.`a_id`))  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `pid` (`pid`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `a_id` (`a_id`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`d_id`),
  ADD KEY `orderid` (`orderid`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`f_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `a_id` (`a_id`);

--
-- Indexes for table `product_details`
--
ALTER TABLE `product_details`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `total_transactions`
--
ALTER TABLE `total_transactions`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_form`
--
ALTER TABLE `user_form`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `delivery`
--
ALTER TABLE `delivery`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `a_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_form`
--
ALTER TABLE `user_form`
  MODIFY `user_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `product` (`pid`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user_form` (`user_id`),
  ADD CONSTRAINT `cart_ibfk_3` FOREIGN KEY (`a_id`) REFERENCES `supplier` (`a_id`);

--
-- Constraints for table `delivery`
--
ALTER TABLE `delivery`
  ADD CONSTRAINT `delivery_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `order_details` (`orderid`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_form` (`user_id`);

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_form` (`user_id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`a_id`) REFERENCES `supplier` (`a_id`);

--
-- Constraints for table `product_details`
--
ALTER TABLE `product_details`
  ADD CONSTRAINT `product_details_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `product` (`pid`);

--
-- Constraints for table `total_transactions`
--
ALTER TABLE `total_transactions`
  ADD CONSTRAINT `total_transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_form` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

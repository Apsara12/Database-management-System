<?php

$conn = mysqli_connect('localhost','root','','bgo') or die('Error'.mysqli_error());

// mysqli_query($conn, "DELETE FROM `cart` WHERE uid= ".$_SESSION['uid']);
session_start();
session_unset();
session_destroy();

header('location:login_page.php');

?>
<header class="header">

   <div class="flex">

      <a href="#" class="logo"><img src="images\last.png" width="125px"></a>

      <nav class="navbar">
      <a href="feedback.php"><img src="images/message1.png" width="30px" height="30px"></a> 
      <a href="delivery.php"><img src="images/order1.png" width="30px" height="30px"></a> 
      <a href="logout.php"><img src="images/lgout.png" width="30px" height="30px"></a>
      </nav>

      

   </div>

</header>
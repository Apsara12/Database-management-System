<header class="header">

   <div class="flex">

      <a href="#" class="logo"><img src="images\last.png" width="125px"></a>

      <nav class="navbar">
      <a href="delivery.php"><img src="images/order1.png" width="30px" height="30px"></a> 
      <a href="admin.php"><img src="images/admin1.png" width="30px" height="30px"></a> 
      <a href="logout.php"><img src="images/lgout.png" width="30px" height="30px" style="color:tomato"></a>
      </nav>

      

   </div>

</header>
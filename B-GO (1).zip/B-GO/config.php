<?php

$conn = mysqli_connect('localhost','root','','bgo') or die('Error'.mysqli_error());

?>
<?php
$conn = mysqli_connect('localhost','root','','bgo') or die('Error'.mysqli_error());
session_start();

if(!isset($_SESSION['uid']))
{
    header('location:login_page.php');
}

// $conn = mysqli_connect('localhost','root','','bgo') or die('Error'.mysqli_error());

if(isset($_POST['add_to_cart'])){
   $product_price = $_POST['product_price'];
   $supplier_id=$_POST['product_supplier'];
   $product_quantity = 1;
   $pid = $_POST['pid'];
    $uid = $_SESSION['uid'];
    $sql = "SELECT * FROM `cart` WHERE pid =".$pid." AND user_id =".$uid;
   $select_cart = mysqli_query($conn, $sql);
   $user_query = mysqli_query($conn, "SELECT * FROM `user_form`");
   if(mysqli_num_rows($user_query) > 0)
   {
    $product_item = mysqli_fetch_assoc($user_query);
    $userid = $product_item['user_id'];
   }

   if(mysqli_num_rows($select_cart) > 0){
      $message[] = 'product already added to cart';
   }else{
      $insert_product = mysqli_query($conn, "INSERT INTO `cart` (pid,quantity, cart_price, user_id,a_id) VALUES($pid,'$product_quantity','$product_price', '$uid',$supplier_id)");
      $message[] = 'product added to cart succesfully';
   }

}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>B-GO | Online Store</title>
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="stylesheet" href="style1.css">
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.1.1/css/fontawesome.min.css"> -->
    <link href="https://fonts.googleapis.com/css2?family=Signika+Negative:wght@300&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<body>
<?php

if(isset($message)){
foreach($message as $messages){
    echo '<div class="messages"><span>'.$messages.'</span> <i class="fas fa-times" onclick="this.parentElement.style.display = `none`;"></i> </div>';
};
};

?>
<div class="header">


<div class="container">

    <div class="navbar">
        <div class="logo">
            <img src="images\last.png" width="125px">

        </div>
        <nav>
            <ul>
                <li><a href="">Home</a></li>
                <li><a href="">Products</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Contact</a></li>
                <li><a href="">Account</a></li>
                <li><a href="cart.php"><img src="images/cart.png" width="30px" height="30px"></a></li>
                <li><a href="logout.php"><i class="fa fa-sign-out fa-2x" aria-hidden="true"></i></a></li>
                
                

        </ul>
                 
        </nav>
        
    

    </div>
    
    <div class="row">
        <div class="col-2">
            <h1>
                Give your day<br> a New Style!
            </h1>
            <p>Get it and give yourslef a style.<br></p><p>Every day a new day to go for.</p>
            <p>Shop Now</p>
            <a href="" class="btn">Explore Now &#8594;</a>

        </div>
        <div class="col-2">
            <img src="images/homepage.jpg" >

        </div>
    </div>

</div>
</div>  



<!-- featured products -->
<section class="products">

        <h2 class="title">Gents Collection</h2>
        <div class="box-container">
        <?php
        $sql = "SELECT * FROM product_info WHERE category = 'gents' AND stock > 0";
      
      $select_products = mysqli_query($conn, $sql);
      if(mysqli_num_rows($select_products) > 0){
         while($fetch_product = mysqli_fetch_assoc($select_products)){
      ?>
       
      <form action="" method="post">
         <div class="box">
            <img src="uploaded_img/<?php echo $fetch_product['image']; ?>" alt="">
            <h3><?php echo $fetch_product['product_name']; ?></h3>
            <h4><?php echo $fetch_product['detail']; ?></h4>
            <h4>Color: <?php echo $fetch_product['colour']; ?></h4>
            <div class="price">Rs:<?php echo $fetch_product['price']; ?>/-</div>
            <input type="hidden" name="pid" value="<?php echo $fetch_product['pid']; ?>">
            <input type="hidden" name="product_name" value="<?php echo $fetch_product['product_name']; ?>">
            <input type="hidden" name="product_colour" value="<?php echo $fetch_product['colour']; ?>">
            <input type="hidden" name="product_desc" value="<?php echo $fetch_product['detail']; ?>">
            <input type="hidden" name="product_category" value="<?php echo $fetch_product['category']; ?>">
            <input type="hidden" name="product_stock" value="<?php echo $fetch_product['stock']; ?>">
            <input type="hidden" name="product_supplier" value="<?php echo $fetch_product['a_id']; ?>">
            <input type="hidden" name="product_price" value="<?php echo $fetch_product['price']; ?>">
            <input type="hidden" name="product_image" value="<?php echo $fetch_product['image']; ?>">
            <input type="submit" class="btn" value="add to cart" name="add_to_cart">
         </div>
      </form>

      <?php
            };
         };
      ?>
        </div>


    </section>
    <br>
    <section class="products">
    
      <h2 class="title">Ladies Collection</h2>
        <div class="box-container">

        <?php
      $sql = "SELECT * FROM product_info WHERE category = 'ladies' AND stock > 0";
      $select_products = mysqli_query($conn, $sql);
      if(mysqli_num_rows($select_products) > 0){
         while($fetch_product = mysqli_fetch_assoc($select_products)){
      ?>
       
      <form action="" method="post">
         <div class="box">
            <img src="uploaded_img/<?php echo $fetch_product['image']; ?>" alt="">
            <h3><?php echo $fetch_product['product_name']; ?></h3>
            <h4><?php echo $fetch_product['detail']; ?></h4>
            <h4>Color: <?php echo $fetch_product['colour']; ?></h4>
            <div class="price">Rs:<?php echo $fetch_product['price']; ?>/-</div>
            <input type="hidden" name="pid" value="<?php echo $fetch_product['pid']; ?>">
            <input type="hidden" name="product_name" value="<?php echo $fetch_product['product_name']; ?>">
            <input type="hidden" name="product_name" value="<?php echo $fetch_product['colour']; ?>">
            <input type="hidden" name="product_desc" value="<?php echo $fetch_product['detail']; ?>">
            <input type="hidden" name="product_category" value="<?php echo $fetch_product['category']; ?>">
            <input type="hidden" name="product_stock" value="<?php echo $fetch_product['stock']; ?>">
            <input type="hidden" name="product_price" value="<?php echo $fetch_product['price']; ?>">
            <input type="hidden" name="product_image" value="<?php echo $fetch_product['image']; ?>">
            <input type="submit" class="btn" value="add to cart" name="add_to_cart">
         </div>
      </form>

      <?php
            };
         };
      ?>
        </div>


    </section>
</div>



<div class="footer">
    <div class="container">
        <div class="row">
            <h3>Project By: Apsara Shrestha | Anuka Kc | Prasamsa Dotel
                
            </h3>
           
        
    </div>
</div>


</body>
</html>
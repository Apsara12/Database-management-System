<header class="header">

   <div class="flex">

      <a href="#" class="logo"><img src="images\last.png" width="125px"></a>

      <nav class="navbar">
      
      <a href="logout.php"><img src="images/lgout.png" width="30px" height="30px"></a>
      </nav>

      

   </div>

</header>